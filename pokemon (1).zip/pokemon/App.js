import React, { useState } from 'react';
import { View, Text, Button, ActivityIndicator, StyleSheet } from 'react-native';

const PokeInfo = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [pokemonData, setPokemonData] = useState(null);
  const [error, setError] = useState(null);

  const fetchPokemonData = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('https://pokeapi.co/api/v2/pokemon/ditto');
      if (!response.ok) {
        throw new Error('Failed to fetch Pokémon data');
      }
      const data = await response.json();
      setPokemonData(data);
      setError(null);
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchRandomPokemon = async () => {
    setIsLoading(true);
    try {
      const randomId = Math.floor(Math.random() * 898) + 1; // There are 898 Pokémon in total
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${randomId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch Pokémon data');
      }
      const data = await response.json();
      setPokemonData(data);
      setError(null);
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.header}>Pokémon Info</Text>
        {isLoading ? (
          <ActivityIndicator style={styles.loader} size="large" color="#ffffff" />
        ) : (
          <>
            {error ? (
              <Text style={styles.error}>{error}</Text>
            ) : (
              <>
                {pokemonData && (
                  <View style={styles.infoContainer}>
                    <Text>Name: {pokemonData.name}</Text>
                    <Text>Height: {pokemonData.height}</Text>
                    <Text>Weight: {pokemonData.weight}</Text>
                    <Text>Abilities:</Text>
                    <View>
                      {pokemonData.abilities.map((ability, index) => (
                        <Text key={index}>{ability.ability.name}</Text>
                      ))}
                    </View>
                  </View>
                )}
                <Button title="Load Ditto" onPress={fetchPokemonData} />
                <Button title="Load Random Pokémon" onPress={fetchRandomPokemon} />
              </>
            )}
          </>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#87CEEB', // Color azul claro
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    backgroundColor: 'rgba(255, 255, 255, 0.8)', // Color de fondo para el contenido
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  loader: {
    marginBottom: 20,
  },
  error: {
    fontSize: 18,
    color: 'red',
    marginBottom: 20,
  },
  infoContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
});

export default PokeInfo;
